""" A simple python project packaging tutorial from here
https://packaging.python.org/en/latest/tutorials/packaging-projects/"""


def add_one(number):
    """
    Toy function
    """
    return number + 1
